package com.example.vv.data


data class BudgetGoal(
    val id: Int = 1, // only one row needed
    val minGoal: Int,
    val maxGoal: Int
)
